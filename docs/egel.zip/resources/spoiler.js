function spoil(id) {
    //alert("spoiling");    
    if(document.getElementById) {
        var divid = document.getElementById(id);
        divid.style.display = (divid.style.display=='block' ? 'none':'block');
    }
}
